/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Lab1;

/**
 *
 * @author chung
 */
public class Main {
    public static void main(String[] args) {
        QLProduct ql = new QLProduct();
        ql.output3Product();
    }
}
