/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package BaiTapTinhDiem;

/**
 *
 * @author chung
 */
public class Main {
    public static void main(String[] args) {
        SinhVienMob sv = new SinhVienMob(10, 10, "Nguyen Ngoc Son");
        sv.inTT();
    }
}
